from django.db import models

# Create your models here.

class Country(models.Model):
    name = models.CharField(max_length=100)
    content = models.TextField()
    color = models.CharField(max_length=7, default="#ffffff")

    def __str__(self):
        return self.name